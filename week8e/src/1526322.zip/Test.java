public class Test {
	public static void main(String[] args) {
		/**
		* Testing Easter.java
		*/
		
		Easter easter = new Easter(1961);
		System.out.println(easter.getDay());
		System.out.println(easter.getMonth());
	}
}
