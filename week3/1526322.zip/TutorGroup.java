import java.util.*;

public class TutorGroup
{
// attributes

	private String tutor;
	private ArrayList<Student> students;

// constructor

	public TutorGroup(String tutor)
	{
		this.tutor = tutor;
		this.students = new ArrayList<Student>();
	}

// toString method
	
	public String toString()
	{
		return "Tutor: " + this.tutor + ", students: " + this.students;
	}
	
// get methods
		
	public ArrayList<Student> getStudents()
	{
		return this.students;
	}
		
// set methods

// misc methods

	public void addStudent(Student student)
	{
		this.students.add(student);
	}

}	
